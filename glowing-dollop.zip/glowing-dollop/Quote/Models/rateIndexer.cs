﻿namespace Quote.Models
{
    public class rateIndexer
    {
        public double value { get; set; }
        public string indexCode { get; set; }
    }
}