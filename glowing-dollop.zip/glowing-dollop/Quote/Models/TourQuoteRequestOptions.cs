﻿namespace Quote.Models
{
    public struct TourQuoteRequestOptions
    {
        public bool GetContracts { get; set; }
        public bool GetCalculatedQuote { get; set; }
    }
}
