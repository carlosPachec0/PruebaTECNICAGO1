﻿namespace Quote.Models.Provider
{
    internal class ExtraData
    {
        public string Id { get; set; }
        public string Value { get; set; }
    }
}
