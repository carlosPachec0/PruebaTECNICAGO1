﻿namespace Quote.Models.Provider
{
    public class ActivitiesDetailResponse : ResponseBase
    {
        public Activity Activity { get; set; }
    }
}
