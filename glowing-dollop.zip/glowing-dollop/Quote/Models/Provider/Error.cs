﻿namespace Quote.Models.Provider
{
    public class Error
    {
        public string Code { get; set; }
        public string Text { get; set; }
    }
}
