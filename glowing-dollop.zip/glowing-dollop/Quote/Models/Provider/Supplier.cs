﻿namespace Quote.Models.Provider
{
    internal class Supplier
    {
            public string Name { get; set; }
            public string VatNumber { get; set; }
    }
}
