﻿namespace Quote.Models.Provider
{
    public class OperationDay
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }
}
