﻿namespace Quote.Models.Provider
{
    internal class BookingReConfirmRequest
    {
        public string Language { get; set; }
        public string Reference { get; set; }
    }
}
