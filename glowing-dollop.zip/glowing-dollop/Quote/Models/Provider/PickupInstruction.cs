﻿namespace Quote.Models.Provider
{
    public class PickupInstruction
    {
        public string Description { get; set; }
    }
}
