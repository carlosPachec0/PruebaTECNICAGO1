﻿namespace Quote.Models.Provider
{
    public class Comment
    {
        public string Description { get; set; }
    }
}
