﻿namespace Quote.Models.Provider
{
    internal class AgencyCommission
    {
        public double Percentage { get; set; }
        public double Amount { get; set; }
        public double VatAmount { get; set; }
    }
}
