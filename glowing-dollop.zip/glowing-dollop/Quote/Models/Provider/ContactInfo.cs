﻿namespace Quote.Models.Provider
{
    internal class ContactInfo
    {
        public string Address { get; set; }
        public Country Country { get; set; }
    }
}
