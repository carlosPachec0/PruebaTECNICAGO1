﻿namespace Quote.Models.Provider
{
    internal class Question2
    {
        public Question Question { get; set; }
        public string Answer { get; set; }
    }
}
