﻿namespace Quote.Models.Provider
{
    public class ModalityComment
    {
        public string Type { get; set; }
        public string Text { get; set; }
    }
}
