﻿using System.Collections.Generic;

namespace Quote.Models.Provider
{
    public class Media
    {
        public List<Image> Images { get; set; }
    }
}
