﻿namespace Quote.Models.Provider
{
    public class Duration
    {
        public double Value { get; set; }
        public string Metric { get; set; }
        public string Type { get; set; }
        public string Description { get; set; }
    }
}
