﻿namespace Quote.Models.Provider
{
    public class Language
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }
}
