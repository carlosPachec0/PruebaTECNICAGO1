﻿namespace Quote.Models.Provider
{
    public class Contract
    {
        public int IncomingOffice { get; set; }
        public int Code { get; set; }
        public string Name { get; set; }
    }
}
