﻿namespace Quote.Models.Provider
{
    public class Pax
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public int Age { get; set; }
        public string Type { get; set; }
    }
}
