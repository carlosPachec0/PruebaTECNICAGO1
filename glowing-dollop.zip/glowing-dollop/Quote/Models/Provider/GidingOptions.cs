﻿namespace Quote.Models.Provider
{
    public class GuidingOptions
    {
        public string GuideType { get; set; }
        public bool Included { get; set; }
        public string Tips { get; set; }
    }
}
