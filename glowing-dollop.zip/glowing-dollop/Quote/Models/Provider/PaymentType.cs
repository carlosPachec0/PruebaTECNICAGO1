﻿namespace Quote.Models.Provider
{
    internal class PaymentType
    {
        public string Code { get; set; }
    }
}
