﻿namespace Quote.Models.Provider
{
    public class Url
    {
        public int Dpi { get; set; }
        public int Height { get; set; }
        public int Width { get; set; }
        public string Resource { get; set; }
        public string SizeType { get; set; }
    }
}
