﻿namespace Quote.Models.Provider
{
    public class Destination
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }
}
