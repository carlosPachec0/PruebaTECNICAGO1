﻿namespace Quote.Models.Provider
{
    public class Feature
    {
        public string FeatureType { get; set; }
        public string Description { get; set; }
    }
}
