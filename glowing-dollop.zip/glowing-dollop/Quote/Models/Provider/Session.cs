﻿namespace Quote.Models.Provider
{
    public class Session
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }
}
