﻿namespace Quote.Models.Provider
{
    internal class ConfirmationComment
    {
        public string Type { get; set; }
        public string Text { get; set; }
    }
}
