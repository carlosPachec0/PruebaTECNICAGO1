﻿namespace Quote.Models.Provider
{
    internal class BookingConfirmResponse : ResponseBase
    {
        public Booking Booking { get; set; }
    }
}
