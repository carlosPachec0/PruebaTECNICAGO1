﻿namespace Quote.Models.Provider
{
    public class Question
    {
        public string Code { get; set; }
        public string Text { get; set; }
        public bool Required { get; set; }
    }
}
