﻿namespace Quote.Models.Provider
{
    public class TotalAmount
    {
        public decimal Amount { get; set; }
        public double BoxOfficeAmount { get; set; }
        public bool MandatoryApplyAmount { get; set; }
    }
}
