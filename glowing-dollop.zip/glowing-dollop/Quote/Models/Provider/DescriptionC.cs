﻿namespace Quote.Models.Provider
{
    public class DescriptionC
    {
        public string Description { get; set; }
    }
}
