﻿namespace Quote.Models.Provider
{
    internal class ProviderInformation
    {
        public string Name { get; set; }
    }
}
