﻿namespace Quote.Models.Provider
{
    public class EndPoint
    {
        public string Type { get; set; }
        public string Description { get; set; }
    }
}
