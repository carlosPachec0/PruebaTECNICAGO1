﻿using System;

namespace Quote.Models.Provider
{
    public class CancellationPolicy
    {
        public DateTime DateFrom { get; set; }
        public double Amount { get; set; }
    }
}
