﻿using System.Collections.Generic;

namespace Quote.Models.Provider
{
    internal class Filter
    {
        public List<SearchFilterItem> SearchFilterItems { get; set; }
    }
}
