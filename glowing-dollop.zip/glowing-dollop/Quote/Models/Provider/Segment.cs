﻿namespace Quote.Models.Provider
{
    public class Segment
    {
        public int Code { get; set; }
        public string Name { get; set; }
    }
}
