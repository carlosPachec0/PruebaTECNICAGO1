﻿namespace Quote.Models
{
    public enum TourCancellationPolicyTypes
    {
        PERCENTAGE = 0,
        AMOUNT = 1
    }
}
