﻿namespace Quote.Models
{
    public enum ExternalProvider
    {
        HotelBedsTours = 39
    }
}
