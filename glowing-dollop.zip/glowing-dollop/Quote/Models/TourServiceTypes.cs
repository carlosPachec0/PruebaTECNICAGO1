﻿namespace Quote.Models
{
    public enum TourServiceTypes
    {
        BASE = 1,
        EXTRA = 2,
        TRANSFER = 3
    }
}
