﻿namespace Quote.Models
{
    public enum Language
    {
        none = 0,
        english = 1,
        Spanish = 2,
        CoSpanish = 5,
    }
}
