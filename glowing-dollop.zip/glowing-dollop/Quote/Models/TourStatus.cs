﻿namespace Quote.Models
{
    public enum TourStatus
    {
        ACTIVE = 2
    }
}
