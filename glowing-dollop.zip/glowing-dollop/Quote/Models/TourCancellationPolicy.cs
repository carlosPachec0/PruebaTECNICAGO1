﻿namespace Quote.Models
{
    public class TourCancellationPolicy
    {
        public int Id { get; set; }
    }
}
