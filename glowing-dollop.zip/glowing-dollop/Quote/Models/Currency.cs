﻿namespace Quote.Models
{
    public enum Currency
    {
        None = 0,
        MXN = 1,
        USD = 2,
        ARS = 3,
        BRL = 4,
        EUR = 5,
        COP = 6,
        CAD = 7,
        PTS = 8,
        PEN = 9
    }
}
