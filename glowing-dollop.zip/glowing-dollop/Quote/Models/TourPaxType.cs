﻿namespace Quote.Models
{
    public enum TourPaxType
    {
        Adult = 1,
        Child = 2
    }
}
