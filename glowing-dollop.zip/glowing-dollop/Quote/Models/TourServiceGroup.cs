﻿namespace Quote.Models
{
    public class TourServiceGroup
    {
        public string nameEn { get; set; }
        public string nameEs { get; set; }
        public string nameAr { get; set; }
        public string nameBr { get; set; }
        public string nameCo { get; set; }
    }
}
